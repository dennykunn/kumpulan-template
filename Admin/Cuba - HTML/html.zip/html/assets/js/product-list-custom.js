"use strict";
(function($) {
    "use strict";
$('#basic-1').DataTable();
})(jQuery);