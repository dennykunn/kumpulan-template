// you can add your custom script here

// popover
var exampleEl = document.getElementsByClassName(".example-popover");
var popover = new bootstrap.Popover(exampleEl, options);

myPopover.show();
